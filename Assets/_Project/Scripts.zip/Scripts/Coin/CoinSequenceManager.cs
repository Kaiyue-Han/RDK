using UnityEngine;

public class CoinSequenceManager : MonoBehaviour
{
    public Coin[] coins;
    private int currentIndex = 0;

    void Start()
    {
        for (int i = 0; i < coins.Length; i++)
        {
            coins[i].Init(this, i);
            coins[i].gameObject.SetActive(true);
            coins[i].SetAsCurrentTarget(i == 0);
        }
    }

    public bool OnCoinCollected(int index)
    {
        if (index != currentIndex) return false;

        coins[currentIndex].SetAsCurrentTarget(false);
        currentIndex++;

        if (currentIndex < coins.Length)
        {
            coins[currentIndex].SetAsCurrentTarget(true);
        }
        else
        {
            Debug.Log("🎉 Get All Coins!");
        }

        return true;
    }
}